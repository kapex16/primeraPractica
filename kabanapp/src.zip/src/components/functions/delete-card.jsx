function EraseCard(allArray, delIndex) {
  return allArray.splice(delIndex, 1);
}

export default EraseCard;
